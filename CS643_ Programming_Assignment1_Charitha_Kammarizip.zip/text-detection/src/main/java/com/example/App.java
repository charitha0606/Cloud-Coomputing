package com.example;

import java.io.*;
import java.nio.ByteBuffer;
import java.util.List;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;

public class App {

    private static final String QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/339713092753/myqueue.fifo";
    private static final String BUCKET_NAME = "njit-cs-643";
    private static final String RESULT_FILE = "results.txt";

    public static void main(String[] args) {
        AmazonSQS sqsService = AmazonSQSClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        AmazonS3 s3Service = AmazonS3ClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        AmazonRekognition rekognitionService = AmazonRekognitionClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        try (BufferedWriter outputWriter = new BufferedWriter(new FileWriter(RESULT_FILE))) {
            while (true) {
                ReceiveMessageRequest messageRequest = new ReceiveMessageRequest(QUEUE_URL).withWaitTimeSeconds(20).withMaxNumberOfMessages(1);
                List<Message> sqsMessages = sqsService.receiveMessage(messageRequest).getMessages();

                for (Message msg : sqsMessages) {
                    String imgName = msg.getBody();
                    if (imgName.equals("-1")) {
                        System.out.println("Processing completed.");
                        sqsService.deleteMessage(QUEUE_URL, msg.getReceiptHandle());
                        return;
                    }

                    S3Object s3Obj = s3Service.getObject(new GetObjectRequest(BUCKET_NAME, imgName));
                    InputStream imgStream = s3Obj.getObjectContent();
                    ByteBuffer imgData = ByteBuffer.wrap(readStream(imgStream));

                    DetectTextRequest textRequest = new DetectTextRequest().withImage(new Image().withBytes(imgData));
                    List<TextDetection> detectedTexts = rekognitionService.detectText(textRequest).getTextDetections();

                    StringBuilder resultLine = new StringBuilder(imgName);
                    boolean isWordDetected = false;
                    for (TextDetection text : detectedTexts) {
                        if ("WORD".equals(text.getType())) {
                            resultLine.append(" ").append(text.getDetectedText());
                            isWordDetected = true;
                        }
                    }

                    if (isWordDetected) {
                        System.out.println(resultLine);
                        outputWriter.write(resultLine.toString());
                        outputWriter.newLine();
                    }

                    sqsService.deleteMessage(QUEUE_URL, msg.getReceiptHandle());
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private static byte[] readStream(InputStream stream) throws IOException {
        ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
        byte[] chunk = new byte[4096];
        int chunkLen;
        while ((chunkLen = stream.read(chunk)) != -1) {
            byteOutput.write(chunk, 0, chunkLen);
        }
        return byteOutput.toByteArray();
    }
}