package com.example;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.SendMessageRequest;

public class App {

    private static final String QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/339713092753/myqueue.fifo";
    private static final String BUCKET_NAME = "njit-cs-643";

    public static void main(String[] args) {
        AmazonRekognition rekognitionService = AmazonRekognitionClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        AmazonSQS sqsService = AmazonSQSClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        AmazonS3 s3Service = AmazonS3ClientBuilder.standard()
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .withRegion(Regions.US_EAST_1)
                .build();

        List<String> objectKeys = retrieveObjectKeys(s3Service);

        System.out.println(objectKeys);

        for (String key : objectKeys) {

            Image image = new Image().withS3Object(new S3Object().withBucket(BUCKET_NAME).withName(key));

            DetectLabelsRequest request = new DetectLabelsRequest()
                    .withImage(image)
                    .withMinConfidence(90F);

            processImage(rekognitionService, sqsService, request, key);
        }

        concludeDetection(sqsService);

        System.out.println("Detection and messaging are complete.");
    }

    private static List<String> retrieveObjectKeys(AmazonS3 s3Service) {
        ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(BUCKET_NAME);
        List<String> keys = new ArrayList<>();

        ListObjectsV2Result result;
        do {
            result = s3Service.listObjectsV2(req);

            for (S3ObjectSummary summary : result.getObjectSummaries()) {
                keys.add(summary.getKey());
            }

            req.setContinuationToken(result.getNextContinuationToken());
        } while (result.isTruncated());

        return keys;
    }

    private static void processImage(AmazonRekognition rekognitionService, AmazonSQS sqsService,
                                     DetectLabelsRequest request, String key) {
        try {
            DetectLabelsResult response = rekognitionService.detectLabels(request);
            List<Label> detectedLabels = response.getLabels();

            if (detectedLabels.stream().anyMatch(label -> "Car".equalsIgnoreCase(label.getName()))) {
                dispatchMessage(sqsService, key);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void dispatchMessage(AmazonSQS sqsService, String messageContent) {
        SendMessageRequest sendMessageReq = new SendMessageRequest()
                .withQueueUrl(QUEUE_URL)
                .withMessageBody(messageContent)
                .withMessageGroupId("1");

        sqsService.sendMessage(sendMessageReq);
    }

    private static void concludeDetection(AmazonSQS sqsService) {
        dispatchMessage(sqsService, "-1");
    }
}
